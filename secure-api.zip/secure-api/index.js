const express = require("express");
const https = require("https");
const fs = require("fs");
const bodyParser = require("body-parser");
const argon2 = require("argon2");  // Import argon2 for password hashing
const { v4: uuidv4 } = require("uuid");  // UUID for generating unique API tokens
const { poolPromise, sql } = require("./dbconfig");
require("dotenv").config();

const app = express();
const port = process.env.PORT || 3001;

// SSL certificates for HTTPS
const sslOptions = {
  key: fs.readFileSync("key.pem"),
  cert: fs.readFileSync("cert.pem"),
};

// Middleware for parsing request bodies
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

// Middleware to verify API token
const verifyToken = async (req, res, next) => {
  const token = req.headers["authorization"];
  if (!token) {
    return res.status(403).json({ success: false, message: "No token provided." });
  }

  const apiToken = token.split(" ")[1]; // Extract token from "Bearer <token>"

  try {
    const pool = await poolPromise;
    const result = await pool
      .request()
      .input("apiToken", sql.VarChar, apiToken)
      .query("SELECT * FROM Users WHERE ApiToken = @apiToken");

    if (result.recordset.length === 0) {
      return res.status(401).json({ success: false, message: "Invalid API token." });
    }

    req.user = result.recordset[0]; // Attach user data to request object
    next(); // Proceed to the next middleware
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

// CRUD Operations

// 1. Create a new user with hashed password and unique API token
app.post("/users", async (req, res) => {
  try {
    const pool = await poolPromise;
    const { name, email, password } = req.body;

    // Hash the user's password using argon2
    const hashedPassword = await argon2.hash(password);

    // Generate a unique API token
    const apiToken = uuidv4();

    // Insert user into the database
    await pool
      .request()
      .input("name", sql.VarChar, name)
      .input("email", sql.VarChar, email)
      .input("hashedPassword", sql.VarChar, hashedPassword)
      .input("apiToken", sql.VarChar, apiToken)
      .query("INSERT INTO Users (Name, Email, PasswordHash, ApiToken) VALUES (@name, @email, @hashedPassword, @apiToken)");

    res.status(201).json({ success: true, message: "User created.", apiToken });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// 2. Read all users (requires valid API token)
app.get("/users", verifyToken, async (req, res) => {
  try {
    const pool = await poolPromise;
    const result = await pool.request().query("SELECT * FROM Users");

    res.status(200).json(result.recordset);
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// 3. Update a user's information and regenerate API token (requires valid API token)
app.put("/users/:id", verifyToken, async (req, res) => {
  try {
    const pool = await poolPromise;
    const { name, email, password } = req.body;
    const { id } = req.params;

    // Hash the new password using argon2
    const hashedPassword = await argon2.hash(password);

    // Generate a new API token
    const apiToken = uuidv4();

    // Update user information
    await pool
      .request()
      .input("id", sql.Int, id)
      .input("name", sql.VarChar, name)
      .input("email", sql.VarChar, email)
      .input("hashedPassword", sql.VarChar, hashedPassword)
      .input("apiToken", sql.VarChar, apiToken)
      .query(`UPDATE Users 
              SET Name = @name, Email = @email, PasswordHash = @hashedPassword, ApiToken = @apiToken 
              WHERE UserID = @id`);

    res.status(200).json({ success: true, message: "User updated.", apiToken });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// 4. Delete a user by ID (requires valid API token)
app.delete("/users/:id", verifyToken, async (req, res) => {
  try {
    const pool = await poolPromise;
    const { id } = req.params;

    // Delete the user from the database
    await pool.request().input("id", sql.Int, id).query("DELETE FROM Users WHERE UserID = @id");

    res.status(200).json({ success: true, message: "User deleted." });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// 5. Login route to authenticate user and return API token
app.post("/login", async (req, res) => {
  try {
    const pool = await poolPromise;
    const { email, password } = req.body;

    // Fetch user by email
    const result = await pool
      .request()
      .input("email", sql.VarChar, email)
      .query("SELECT * FROM Users WHERE Email = @email");

    if (result.recordset.length === 0) {
      return res.status(404).json({ success: false, message: "User not found." });
    }

    const user = result.recordset[0];

    // Verify the password using argon2
    const isPasswordValid = await argon2.verify(user.PasswordHash, password);

    if (!isPasswordValid) {
      return res.status(401).json({ success: false, message: "Invalid password." });
    }

    // Return the API token to the user
    res.status(200).json({ success: true, message: "Login successful.", apiToken: user.ApiToken });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// 6. Read all Courses (requires valid API token)
app.get("/courses", verifyToken, async (req, res) => {
    try {
      const pool = await poolPromise;
      const result = await pool.request().query("SELECT * FROM tblMST_Courses");
  
      res.status(200).json(result.recordset);
    } catch (err) {
      res.status(500).json({ success: false, message: err.message });
    }
  });
// Start the HTTPS server
https.createServer(sslOptions, app).listen(port, () => {
  console.log(`Server is running on https://localhost:${port}`);
});
